namespace Projekcik
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        int[] Convert(string napis)
        {
            var liczbaS = napis.Trim().Split(' ');
            var wynik = new int[liczbaS.Length];
            for(int i= 0; i < liczbaS.Length; i++)
                wynik[i] = int.Parse(liczbaS[i]);
            return wynik;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}