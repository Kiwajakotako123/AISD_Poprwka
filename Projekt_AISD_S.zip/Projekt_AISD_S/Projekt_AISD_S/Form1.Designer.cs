﻿namespace Projekt_AISD_S
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            tbxWynikTablicy = new TextBox();
            btnSB = new Button();
            lblCzasWyk = new Button();
            btnSS = new Button();
            btnSI = new Button();
            btnSM = new Button();
            btnSQ = new Button();
            btnGenerate = new Button();
            checkBox1 = new CheckBox();
            numericUpDown1 = new NumericUpDown();
            Losuj = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            btnCzyszczenie = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 55);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(267, 23);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // tbxWynikTablicy
            // 
            tbxWynikTablicy.Location = new Point(12, 219);
            tbxWynikTablicy.Name = "tbxWynikTablicy";
            tbxWynikTablicy.Size = new Size(267, 23);
            tbxWynikTablicy.TabIndex = 1;
            tbxWynikTablicy.TextChanged += tbxWynikTablicy_TextChanged;
            // 
            // btnSB
            // 
            btnSB.BackColor = SystemColors.Info;
            btnSB.Location = new Point(59, 325);
            btnSB.Name = "btnSB";
            btnSB.Size = new Size(48, 23);
            btnSB.TabIndex = 2;
            btnSB.Text = "SB";
            btnSB.UseVisualStyleBackColor = false;
            btnSB.Click += btnSB_Click;
            // 
            // lblCzasWyk
            // 
            lblCzasWyk.BackColor = SystemColors.ControlDark;
            lblCzasWyk.Location = new Point(417, 219);
            lblCzasWyk.Name = "lblCzasWyk";
            lblCzasWyk.Size = new Size(176, 23);
            lblCzasWyk.TabIndex = 3;
            lblCzasWyk.Text = "Czas";
            lblCzasWyk.UseVisualStyleBackColor = false;
            lblCzasWyk.Click += lblCzasWyk_Click;
            // 
            // btnSS
            // 
            btnSS.BackColor = SystemColors.Info;
            btnSS.Location = new Point(168, 325);
            btnSS.Name = "btnSS";
            btnSS.Size = new Size(47, 23);
            btnSS.TabIndex = 4;
            btnSS.Text = "SS";
            btnSS.UseVisualStyleBackColor = false;
            btnSS.Click += btnSS_Click;
            // 
            // btnSI
            // 
            btnSI.BackColor = SystemColors.Info;
            btnSI.Location = new Point(285, 325);
            btnSI.Name = "btnSI";
            btnSI.Size = new Size(52, 23);
            btnSI.TabIndex = 5;
            btnSI.Text = "SI";
            btnSI.UseVisualStyleBackColor = false;
            btnSI.Click += btnSI_Click;
            // 
            // btnSM
            // 
            btnSM.BackColor = SystemColors.Info;
            btnSM.Location = new Point(408, 325);
            btnSM.Name = "btnSM";
            btnSM.Size = new Size(51, 23);
            btnSM.TabIndex = 6;
            btnSM.Text = "SM";
            btnSM.UseVisualStyleBackColor = false;
            btnSM.Click += btnSM_Click;
            // 
            // btnSQ
            // 
            btnSQ.BackColor = SystemColors.Info;
            btnSQ.Location = new Point(524, 325);
            btnSQ.Name = "btnSQ";
            btnSQ.Size = new Size(47, 23);
            btnSQ.TabIndex = 7;
            btnSQ.Text = "SQ";
            btnSQ.UseVisualStyleBackColor = false;
            btnSQ.Click += btnSQ_Click;
            // 
            // btnGenerate
            // 
            btnGenerate.BackColor = SystemColors.ActiveCaption;
            btnGenerate.Location = new Point(476, 139);
            btnGenerate.Name = "btnGenerate";
            btnGenerate.Size = new Size(117, 23);
            btnGenerate.TabIndex = 8;
            btnGenerate.Text = "Generuj Tablice";
            btnGenerate.UseVisualStyleBackColor = false;
            btnGenerate.Click += btnGenerate_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = SystemColors.Control;
            checkBox1.Location = new Point(348, 55);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(15, 14);
            checkBox1.TabIndex = 9;
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(473, 52);
            numericUpDown1.Maximum = new decimal(new int[] { 2000000, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(120, 23);
            numericUpDown1.TabIndex = 10;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // Losuj
            // 
            Losuj.BackColor = SystemColors.ActiveCaption;
            Losuj.Location = new Point(476, 92);
            Losuj.Name = "Losuj";
            Losuj.Size = new Size(117, 23);
            Losuj.TabIndex = 11;
            Losuj.Text = "Losuj ilośc znaków";
            Losuj.UseVisualStyleBackColor = false;
            Losuj.Click += Losuj_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(85, 28);
            label1.Name = "label1";
            label1.Size = new Size(102, 15);
            label1.TabIndex = 12;
            label1.Text = "Wypisz tabele cyfr";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(85, 188);
            label2.Name = "label2";
            label2.Size = new Size(114, 15);
            label2.TabIndex = 13;
            label2.Text = "Posortowana tablica";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(50, 298);
            label3.Name = "label3";
            label3.Size = new Size(68, 15);
            label3.TabIndex = 14;
            label3.Text = "Bubble Sort";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(154, 298);
            label4.Name = "label4";
            label4.Size = new Size(79, 15);
            label4.TabIndex = 15;
            label4.Text = "Selection Sort";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(285, 298);
            label5.Name = "label5";
            label5.Size = new Size(60, 15);
            label5.TabIndex = 16;
            label5.Text = "Insert Sort";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(408, 298);
            label6.Name = "label6";
            label6.Size = new Size(65, 15);
            label6.TabIndex = 17;
            label6.Text = "Merge Sort";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(524, 298);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 18;
            label7.Text = "Quick Sort";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(452, 188);
            label8.Name = "label8";
            label8.Size = new Size(106, 15);
            label8.TabIndex = 19;
            label8.Text = "Czas Posortowania";
            // 
            // btnCzyszczenie
            // 
            btnCzyszczenie.BackColor = SystemColors.ActiveCaptionText;
            btnCzyszczenie.ForeColor = SystemColors.ButtonHighlight;
            btnCzyszczenie.Location = new Point(96, 92);
            btnCzyszczenie.Name = "btnCzyszczenie";
            btnCzyszczenie.Size = new Size(75, 23);
            btnCzyszczenie.TabIndex = 20;
            btnCzyszczenie.Text = "Wyczyść";
            btnCzyszczenie.UseVisualStyleBackColor = false;
            btnCzyszczenie.Click += btnCzyszczenie_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(640, 381);
            Controls.Add(btnCzyszczenie);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Losuj);
            Controls.Add(numericUpDown1);
            Controls.Add(checkBox1);
            Controls.Add(btnGenerate);
            Controls.Add(btnSQ);
            Controls.Add(btnSM);
            Controls.Add(btnSI);
            Controls.Add(btnSS);
            Controls.Add(lblCzasWyk);
            Controls.Add(btnSB);
            Controls.Add(tbxWynikTablicy);
            Controls.Add(textBox1);
            ForeColor = SystemColors.Desktop;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox tbxWynikTablicy;
        private Button btnSB;
        private Button lblCzasWyk;
        private Button btnSS;
        private Button btnSI;
        private Button btnSM;
        private Button btnSQ;
        private Button btnGenerate;
        private CheckBox checkBox1;
        private NumericUpDown numericUpDown1;
        private Button Losuj;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Button btnCzyszczenie;
    }
}